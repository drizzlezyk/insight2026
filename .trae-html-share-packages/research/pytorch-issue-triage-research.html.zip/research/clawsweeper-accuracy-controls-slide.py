from pathlib import Path

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Inches, Pt


OUT = Path(__file__).with_name("clawsweeper-accuracy-controls-slide.pptx")

COLORS = {
    "bg": "F6F8FA",
    "white": "FFFFFF",
    "ink": "17212B",
    "body": "3D4B59",
    "muted": "657482",
    "line": "DCE3E8",
    "blue": "3569A8",
    "teal": "087E78",
    "green": "267348",
    "amber": "A45A08",
    "red": "A33D36",
    "red_bg": "F8EEEE",
}

FONT = "Microsoft YaHei"
MONO = "Consolas"

SOURCES = {
    "workflow": "https://github.com/openclaw/clawsweeper/blob/main/.github/workflows/review-plan.yml#L322-L344",
    "review": "https://github.com/openclaw/clawsweeper/blob/main/src/clawsweeper-review-core.ts#L347-L375",
    "parser": "https://github.com/openclaw/clawsweeper/blob/main/src/clawsweeper-decision-parser.ts#L817-L885",
    "labels": "https://github.com/openclaw/clawsweeper/blob/main/src/clawsweeper-label-selection.ts#L124-L214",
    "apply": "https://github.com/openclaw/clawsweeper/blob/main/src/clawsweeper-apply-report-labels.ts#L110-L168",
    "quality": "https://clawsweeper.openclaw.ai/quality/",
}


def color(value):
    return RGBColor.from_string(value)


def set_run(run, text, size, hex_color, bold=False, font=FONT, hyperlink=None):
    run.text = text
    run.font.name = font
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = color(hex_color)
    if hyperlink:
        run.hyperlink.address = hyperlink


def add_text(slide, x, y, w, h, text, size, hex_color, bold=False,
             font=FONT, align=PP_ALIGN.LEFT, valign=MSO_ANCHOR.MIDDLE,
             margin=0.02):
    shape = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    frame = shape.text_frame
    frame.clear()
    frame.word_wrap = True
    frame.margin_left = Inches(margin)
    frame.margin_right = Inches(margin)
    frame.margin_top = Inches(0.01)
    frame.margin_bottom = Inches(0.01)
    frame.vertical_anchor = valign
    paragraph = frame.paragraphs[0]
    paragraph.alignment = align
    set_run(paragraph.add_run(), text, size, hex_color, bold, font)
    return shape


def add_rich_line(slide, x, y, w, h, parts, size=8.1):
    shape = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    frame = shape.text_frame
    frame.clear()
    frame.word_wrap = False
    frame.margin_left = Inches(0.02)
    frame.margin_right = Inches(0.02)
    frame.margin_top = Inches(0.01)
    frame.margin_bottom = Inches(0.01)
    frame.vertical_anchor = MSO_ANCHOR.MIDDLE
    paragraph = frame.paragraphs[0]
    for text, url in parts:
        set_run(paragraph.add_run(), text, size, COLORS["blue"], font=MONO, hyperlink=url)
    return shape


def add_card(slide, x, number, accent, eyebrow, title, lines, source_label, source_url):
    y, w, h = 1.94, 2.93, 3.22
    card = slide.shapes.add_shape(
        MSO_SHAPE.ROUNDED_RECTANGLE,
        Inches(x), Inches(y), Inches(w), Inches(h),
    )
    card.fill.solid()
    card.fill.fore_color.rgb = color(COLORS["white"])
    card.line.color.rgb = color(COLORS["line"])
    card.line.width = Pt(0.8)
    card.adjustments[0] = 0.06

    stripe = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE,
        Inches(x), Inches(y), Inches(0.055), Inches(h),
    )
    stripe.fill.solid()
    stripe.fill.fore_color.rgb = color(accent)
    stripe.line.fill.background()

    add_text(slide, x + 0.22, y + 0.20, 0.42, 0.22, number, 9, accent, True, MONO)
    add_text(slide, x + 0.69, y + 0.20, w - 0.91, 0.22, eyebrow, 8.0, COLORS["muted"], True, MONO)
    add_text(slide, x + 0.22, y + 0.54, w - 0.42, 0.34, title, 13.0, COLORS["ink"], True)

    body = slide.shapes.add_textbox(
        Inches(x + 0.22), Inches(y + 1.02), Inches(w - 0.43), Inches(1.77)
    )
    frame = body.text_frame
    frame.clear()
    frame.word_wrap = True
    frame.margin_left = Inches(0)
    frame.margin_right = Inches(0)
    frame.margin_top = Inches(0)
    frame.margin_bottom = Inches(0)
    frame.vertical_anchor = MSO_ANCHOR.TOP
    for index, line in enumerate(lines):
        paragraph = frame.paragraphs[0] if index == 0 else frame.add_paragraph()
        paragraph.text = f"• {line}"
        paragraph.level = 0
        paragraph.space_after = Pt(7)
        paragraph.font.name = FONT
        paragraph.font.size = Pt(9.0)
        paragraph.font.color.rgb = color(COLORS["body"])

    source = add_text(
        slide, x + 0.22, y + 2.88, w - 0.42, 0.19,
        source_label, 7.2, COLORS["blue"], False, MONO,
    )
    for run in source.text_frame.paragraphs[0].runs:
        run.hyperlink.address = source_url


def build():
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    slide.background.fill.solid()
    slide.background.fill.fore_color.rgb = color(COLORS["bg"])

    add_text(slide, 0.57, 0.25, 5.4, 0.24, "OPENCLAW × CLAWSWEEPER  /  QUALITY CONTROLS",
             8.4, COLORS["teal"], True, MONO)
    add_text(slide, 0.57, 0.60, 11.8, 0.47, "准确性控制：模型给判断，代码管边界",
             23.5, COLORS["ink"], True)
    add_text(
        slide, 0.59, 1.16, 12.1, 0.38,
        "以证据、结构校验、确定性规则和受控写回降低错误风险；这是多层护栏，不是准确率保证。",
        10.2, COLORS["muted"],
    )
    add_text(slide, 11.7, 0.28, 1.06, 0.20, "REVIEW / 01", 8.2,
             COLORS["muted"], False, MONO, PP_ALIGN.RIGHT)

    cards = [
        (
            0.55, "01", COLORS["blue"], "EVIDENCE",
            "审查有证据边界",
            [
                "汇集 Issue 正文、讨论、关联项与当前源码。",
                "要求明示证据及覆盖缺口；未读到不等于不存在。",
                "Codex 使用受限 sandbox 与只读 GitHub token。",
            ],
            "review-core.ts", SOURCES["review"],
        ),
        (
            3.69, "02", COLORS["teal"], "SCHEMA GATE",
            "输出先过机器校验",
            [
                "Decision JSON 严格检查字段、枚举、分数范围与字段关系。",
                "标签必须在白名单内；每个选中标签都要有理由。",
                "缺字段、越界或矛盾即拒绝，不进入后续同步。",
            ],
            "decision-parser.ts", SOURCES["parser"],
        ),
        (
            6.83, "03", COLORS["green"], "POLICY",
            "标签由确定性规则映射",
            [
                "规则读取已校验 Decision 与 Issue 当前状态，不直接信任原始 JSON。",
                "queueable-fix 要求候选路径、candidate 状态、高置信度且非 bulk。",
                "证据不足或涉及安全、产品决策时，转补证或人工处理标记。",
            ],
            "label-selection.ts", SOURCES["labels"],
        ),
        (
            9.97, "04", COLORS["amber"], "CONTROLLED APPLY",
            "写回与模型隔离",
            [
                "模型只读；宿主 Apply 阶段另行检查状态、时效与保护条件。",
                "只有合格报告才同步建议标签或执行允许的操作。",
                "维护者仍负责需人工判断的边界案例。",
            ],
            "apply-report-labels.ts", SOURCES["apply"],
        ),
    ]
    for card in cards:
        add_card(slide, *card)

    panel = slide.shapes.add_shape(
        MSO_SHAPE.ROUNDED_RECTANGLE,
        Inches(0.55), Inches(5.43), Inches(12.35), Inches(1.02),
    )
    panel.fill.solid()
    panel.fill.fore_color.rgb = color(COLORS["red_bg"])
    panel.line.color.rgb = color("EAD6D3")
    panel.line.width = Pt(0.8)
    panel.adjustments[0] = 0.06
    add_text(slide, 0.79, 5.60, 1.68, 0.25, "准确性边界", 11.0, COLORS["red"], True)
    add_text(
        slide, 2.40, 5.54, 10.17, 0.52,
        "这些护栏能拦截格式错误、越权写入和部分规则违例，不能保证模型语义判断无误。公开 Assessments 页面也明示：记录不是独立准确率测量；未见公开 gold-set、precision / recall。",
        9.1, COLORS["body"],
    )

    add_text(slide, 0.57, 6.70, 0.72, 0.20, "源码", 7.7, COLORS["muted"], True)
    source_parts = [
        ("review-plan.yml", SOURCES["workflow"]),
        ("  ·  review-core.ts", SOURCES["review"]),
        ("  ·  decision-parser.ts", SOURCES["parser"]),
        ("  ·  label-selection.ts", SOURCES["labels"]),
        ("  ·  apply-report-labels.ts", SOURCES["apply"]),
        ("  ·  Assessments", SOURCES["quality"]),
    ]
    add_rich_line(slide, 1.22, 6.69, 11.5, 0.22, source_parts, 7.6)
    add_text(
        slide, 0.57, 7.04, 12.2, 0.16,
        "解读口径：护栏与流程控制 ≠ 统计学准确率；Dashboard snapshot checked 2026-11-09。",
        7.0, COLORS["muted"], False, FONT,
    )

    prs.save(OUT)
    return OUT


if __name__ == "__main__":
    print(build())
